<?php $__env->startSection('content'); ?>

    <div class="bgc-white bd bdrs-3 p-20 mB-20">
        <h4 class="c-grey-900 mB-20">Tableau des demandes</h4>
        <table id="dataTable" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Type</th>
                    <th>Code</th>
                    <th>Nom Commercial</th>
                    <th>Titulaire de l'AMM</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>Type</th>
                    <th>Code</th>
                    <th>Nom Commercial</th>
                    <th>Titulaire de l'AMM</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </tfoot>
            <tbody>
                <?php $__currentLoopData = $demande; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $demande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($demande->type); ?></td>
                    <td><?php echo e($demande->code); ?></td>
                    <td><?php echo e($demande->nom_medicament); ?></td>
                    <?php if($demande->role == 'labo'): ?>
                        <td>------------</td>
                    <?php else: ?>
                        <td><?php echo e($demande->labo); ?></td>
                    <?php endif; ?>

                    <?php if($demande->status == 'Acceptée'): ?>
                        <td><span class="badge bgc-green-50 c-green-700 p-10 lh-0 tt-c badge-pill"><?php echo e($demande->status); ?></span></td>
                    <?php elseif($demande->status == 'Rejetée'): ?>
                        <td><span class="badge bgc-red-50 c-red-700 p-10 lh-0 tt-c badge-pill"><?php echo e($demande->status); ?></span></td>
                    <?php else: ?>
                        <td><span class="badge bgc-yellow-50 c-yellow-700 p-10 lh-0 tt-c badge-pill"><?php echo e($demande->status); ?></span></td>
                    <?php endif; ?>
                    <td>
                        <a href="<?php echo e(url('/demande/' . $demande->id)); ?>" class="btn btn-action btn-secondary">Detail</a>

                        <?php if(Auth()->check() && Auth()->user()->role != 'pharmacien'): ?>

                            <button class="item" disabled data-toggle="tooltip" data-placement="top" title="Suivre">
                                <i class=""><a href="<?php echo e(url('/demande/create?id=' . $demande->id)); ?>">Suivre</a></i>
                            </button>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT-Manager\Downloads\homologation-master(1)\homologation-master\resources\views/demande/index.blade.php ENDPATH**/ ?>