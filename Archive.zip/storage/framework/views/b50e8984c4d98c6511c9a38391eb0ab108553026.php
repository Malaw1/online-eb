<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Autorisation de Mise sur le Marche
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Numero</th>
                                    <th>Produit</th>
                                    <th>Classe Therapeutique</th>
                                    <th>Date de l'AMM</th>
                                    <th>Date d'expiration</th>
                                    <th>Laboratoire detenteur</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>#</th>
                                    <th>Numero</th>
                                    <th>Produit</th>
                                    <th>Classe Therapeutique</th>
                                    <th>Date de l'AMM</th>
                                    <th>Date d'expiration</th>
                                    <th>Laboratoire detenteur</th>
                                    <th></th>
                                </tr>
                            </tfoot>
                            <tbody>
                            <?php $__currentLoopData = $amm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $demande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td></td>
                                        <td><?php echo e($demande->numero); ?></td>
                                        <td><?php echo e($demande->nom_medicament); ?></td>
                                        <td><?php echo e($demande->classe_therapeutique); ?></td>
                                        <td><?php echo e($demande->created_at); ?></td>
                                        <td><?php echo e($demande->expiration); ?></td>
                                        <?php if($demande->role != 'labo'): ?>
                                            <td><?php echo e($demande->labo); ?></td>
                                        <?php else: ?>
                                            <td>-----------</td>
                                        <?php endif; ?>
                                        <td>
                                            <a href="<?php echo e(url('/autorisation/' . $demande->id)); ?>"
                                            title="View Client">
                                                <button class="btn btn-info btn-sm">
                                                    <i class="fa fa-eye" aria-hidden="true"></i> Voire
                                                </button>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT-Manager\Downloads\homologation-master(1)\homologation-master\resources\views/autorisation/index.blade.php ENDPATH**/ ?>