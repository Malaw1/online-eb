{{ $data['message']}}

<p>Direction de la Pharmacie et du Medicament</p>
<a href="facebook.com">Follow this Link to test </a>
