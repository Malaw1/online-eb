<?php

namespace App\Http\Controllers;

use App\Complement;
use Illuminate\Http\Request;

class ComplementController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Complement  $complement
     * @return \Illuminate\Http\Response
     */
    public function show(Complement $complement)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Complement  $complement
     * @return \Illuminate\Http\Response
     */
    public function edit(Complement $complement)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Complement  $complement
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Complement $complement)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Complement  $complement
     * @return \Illuminate\Http\Response
     */
    public function destroy(Complement $complement)
    {
        //
    }
}
