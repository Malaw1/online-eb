<?php

namespace App\Http\Controllers;

use App\Rejected;
use Illuminate\Http\Request;

class RejectedController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Rejected  $rejected
     * @return \Illuminate\Http\Response
     */
    public function show(Rejected $rejected)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Rejected  $rejected
     * @return \Illuminate\Http\Response
     */
    public function edit(Rejected $rejected)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Rejected  $rejected
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Rejected $rejected)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Rejected  $rejected
     * @return \Illuminate\Http\Response
     */
    public function destroy(Rejected $rejected)
    {
        //
    }
}
